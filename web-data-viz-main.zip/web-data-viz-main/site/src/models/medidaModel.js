var database = require("../database/config");

function buscarUltimasMedidas(fkSensores, limite_linhas) {

    instrucaoSql = ''

    if (process.env.AMBIENTE_PROCESSO == "producao") {
        instrucaoSql = `select tempDHT11 as temp1,
        tempLM35 as temp2,
        umidade,
        date_format(dtHora_leitura, '%H:%i:%s') as momento_grafico
        from leitura
        where fkSensores = ${fkSensores}
        order by idLeitura desc limit 7`;
    } else if (process.env.AMBIENTE_PROCESSO == "desenvolvimento") {
        instrucaoSql = `select tempDHT11 as temp1,
        tempLM35 as temp2,
        umidade,
        date_format(dtHora_leitura, '%H:%i:%s') as momento_grafico
        from leitura
        where fkSensores = ${fkSensores}
        order by idLeitura desc limit 7`;
    } else {
        console.log("\nO AMBIENTE (produção OU desenvolvimento) NÃO FOI DEFINIDO EM app.js\n");
        return
    }

    console.log("Executando a instrução SQL: \n" + instrucaoSql);
    return database.executar(instrucaoSql);
}

function buscarMedidasEmTempoReal(fkSensores) {

    instrucaoSql = ''

    if (process.env.AMBIENTE_PROCESSO == "producao") {
        instrucaoSql = `select tempDHT11 as temp1,
        tempLM35 as temp2,
        umidade,
        date_format(dtHora_leitura, '%H:%i:%s') as momento_grafico
        from leitura
        where fkSensores = ${fkSensores}
        order by idLeitura desc limit 7`;

    } else if (process.env.AMBIENTE_PROCESSO == "desenvolvimento") {
        instrucaoSql = `select tempDHT11 as temp1,
        tempLM35 as temp2,
        umidade,
        date_format(dtHora_leitura, '%H:%i:%s') as momento_grafico
        from leitura
        where fkSensores = ${fkSensores}
        order by idLeitura desc limit 7`;
    } else {
        console.log("\nO AMBIENTE (produção OU desenvolvimento) NÃO FOI DEFINIDO EM app.js\n");
        return
    }

    console.log("Executando a instrução SQL: \n" + instrucaoSql);
    return database.executar(instrucaoSql);
}


module.exports = {
    buscarUltimasMedidas,
    buscarMedidasEmTempoReal
}
