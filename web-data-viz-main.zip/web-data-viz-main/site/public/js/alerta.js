var alertas = [];

function obterdados(fkSensores) {
    fetch(`/medidas/tempo-real/${fkSensores}`)
        .then(resposta => {

            if (resposta.ok) {
                resposta.json().then(resposta => {

                    console.log(`Dados recebidos: ${JSON.stringify(resposta)}`);

                    alertar(resposta, fkSensores);
                });
            } else {

                console.error('Nenhum dado encontrado ou erro na API');
            }
        })
        .catch(function (error) {
            console.error(`Erro na obtenção dos dados do aquario p/ gráfico: ${error.message}`);
        });

}

function alertar(resposta, fkSensores) {
    var temp = resposta[0].temp1;

    console.log(fkSensores === resposta[0].fk_aquario)
    
    var grauDeAviso ='';


    var limites = {
        muito_quente: 8,
        quente: 4,
        ideal: 2,
        frio: 0,
        muito_frio: -5
    };

    // var classe_temperatura = 'cor-alerta';

    if (temp >= limites.muito_quente) {
        classe_temperatura = 'cor-alerta perigo-quente';
        grauDeAviso = 'perigo quente'
        grauDeAvisoCor = 'cor-alerta perigo-quente'
        exibirAlerta(temp, fkSensores, grauDeAviso, grauDeAvisoCor)
    }
    else if (temp < limites.muito_quente && temp >= limites.quente) {
        classe_temperatura = 'cor-alerta alerta-quente';
        grauDeAviso = 'alerta quente'
        grauDeAvisoCor = 'cor-alerta alerta-quente'
        exibirAlerta(temp, fkSensores, grauDeAviso, grauDeAvisoCor)
    }
    else if (temp < limites.quente && temp > limites.frio) {
        classe_temperatura = 'cor-alerta ideal';
        removerAlerta(fkSensores);
    }
    else if (temp <= limites.frio && temp > limites.muito_frio) {
        classe_temperatura = 'cor-alerta alerta-frio';
        grauDeAviso = 'alerta frio'
        grauDeAvisoCor = 'cor-alerta alerta-frio'
        exibirAlerta(temp, fkSensores, grauDeAviso, grauDeAvisoCor)
    }
    else if (temp <= limites.muito_frio) {
        classe_temperatura = 'cor-alerta perigo-frio';
        grauDeAviso = 'perigo frio'
        grauDeAvisoCor = 'cor-alerta perigo-frio'
        exibirAlerta(temp, fkSensores, grauDeAviso, grauDeAvisoCor)
    }

    var card;

    if (fkSensores == 1) {
        temp.innerHTML = temp + "°C";
    }

    // card.className = classe_temperatura;
}

function exibirAlerta(temp, fkSensores, grauDeAviso, grauDeAvisoCor) {
    var indice = alertas.findIndex(item => item.fkSensores == fkSensores);

    if (indice >= 0) {
        alertas[indice] = { fkSensores, temp, grauDeAviso, grauDeAvisoCor }
    } else {
        alertas.push({ fkSensores, temp, grauDeAviso, grauDeAvisoCor });
    }

    exibirCards();
    
// Dentro da div com classe grauDeAvisoCor há um caractere "invisível", 
// que pode ser inserido clicando com o seu teclado em alt+255 ou pelo código adicionado acima.
}

function removerAlerta(fkSensores) {
    alertas = alertas.filter(item => item.fkSensores != fkSensores);
    exibirCards();
}
 
function exibirCards() {
    alerta.innerHTML = '';

    for (var i = 0; i < alertas.length; i++) {
        var mensagem = alertas[i];
        alerta.innerHTML += transformarEmDiv(mensagem);
    }
}

function transformarEmDiv({ fkSensores, temp, grauDeAviso, grauDeAvisoCor }) {
    return `<div class="mensagem-alarme">
    <div class="informacao">
    <div class="${grauDeAvisoCor}">&#12644;</div> 
     <h3>A temperatura da sua cozinha ${fkSensores} está em estado de ${grauDeAviso}!</h3>
    <small>Temperatura ${temp}°C.</small>
    <br>
    <small>O ideial é: 3°C</small>   
    </div>
    <div class="alarme-sino"></div>
    </div>`;
}